from pyspark.sql import SparkSession
from pyspark.sql.functions import sum, avg

# Step 1: Initialize Spark session
spark = SparkSession.builder \
    .appName("Prepare Big Data for Tableau Visualization") \
    .getOrCreate()

# Step 2: Load large dataset (replace with your actual data source)
data = [
    (1, "John", "HR", 40000),
    (2, "Alice", "IT", 60000),
    (3, "Bob", "HR", 35000),
    (4, "Charlie", "IT", 70000),
    (5, "Eve", "Finance", 45000),
    (6, "Frank", "Finance", 30000)
]
columns = ["ID", "Name", "Department", "Salary"]

df = spark.createDataFrame(data, columns)

# Step 3: Filter and aggregate the data
filtered_df = df.filter(df["Salary"] > 40000)

summary_df = filtered_df.groupBy("Department") \
    .agg(
        sum("Salary").alias("Total_Salary"),
        avg("Salary").alias("Average_Salary")
    )

# Step 4: Export result to CSV (for Tableau)
summary_df.coalesce(1).write \
    .option("header", True) \
    .csv("output/department_salary_summary")

# Step 5: Stop Spark session
spark.stop()
