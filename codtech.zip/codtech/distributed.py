from pyspark.sql import SparkSession
from pyspark.sql.functions import sum, avg

# Step 1: Initialize Spark Session
spark = SparkSession.builder \
    .appName("Distributed Data Processing Example") \
    .getOrCreate()

# Step 2: Create a DataFrame (Normally you would read from a Big CSV/Database)
data = [
    (1, "John", "HR", 40000),
    (2, "Alice", "IT", 60000),
    (3, "Bob", "HR", 35000),
    (4, "Charlie", "IT", 70000),
    (5, "Eve", "Finance", 45000),
    (6, "Frank", "Finance", 30000)
]

columns = ["ID", "Name", "Department", "Salary"]

df = spark.createDataFrame(data, columns)

# Step 3: Filter employees with Salary > 40000
filtered_df = df.filter(df.Salary > 40000)

# Step 4: Group by Department
grouped_df = filtered_df.groupBy("Department") \
    .agg(
        sum("Salary").alias("Total_Salary"),
        avg("Salary").alias("Average_Salary")
    )

# Step 5: Show the results
grouped_df.show()

# Step 6: Stop the Spark Session
spark.stop()
