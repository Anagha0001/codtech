from pyspark.sql import SparkSession
from pyspark.sql.functions import sha2, col

# Start secure Spark session
spark = SparkSession.builder \
    .appName("SecureDataProcessing") \
    .config("spark.io.encryption.enabled", "true") \
    .config("spark.authenticate", "true") \
    .config("spark.authenticate.secret", "mySuperSecretKey") \
    .getOrCreate()

# Load sensitive data
data = [
    ("Alice", "alice@example.com", "123-45-6789"),
    ("Bob", "bob@example.com", "987-65-4321")
]
columns = ["Name", "Email", "SSN"]

df = spark.createDataFrame(data, columns)

# Mask SSN using hashing
secure_df = df.withColumn("Masked_SSN", sha2(col("SSN"), 256)).drop("SSN")

secure_df.show()
spark.stop()
